<script type='text/javascript' src='<?php echo get_stylesheet_directory_uri();?>/assets/js/timer.js'></script>

<script type='text/javascript' src='<?php echo get_stylesheet_directory_uri();?>/assets/js/wp-embed.min.js'></script>
<script src="<?php echo get_stylesheet_directory_uri();?>/assets/js/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/angularjs/1.5.8/angular-animate.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/angularjs/1.5.8/angular-sanitize.js"></script>
<script src="//angular-ui.github.io/bootstrap/ui-bootstrap-tpls-2.2.0.js"></script>
<!--<link href="//netdna.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
-->
<?php wp_footer(); ?>

</body>
</html>
